MODEL = "llama3.2:latest"
EMBD_MODEL = "mxbai-embed-large:latest"

DB_FOLDER = "chat_backup"
DB = "chatbot.db"
LT_MEMORY_DB = "memory.db"

VECTOR_DB_FOLDER = "vector_db"



